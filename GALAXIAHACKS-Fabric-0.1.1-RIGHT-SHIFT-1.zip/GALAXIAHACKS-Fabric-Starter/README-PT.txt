GALAXIAHACKS — Fabric Starter 0.1.1
====================================

ALTERAÇÃO DESTA VERSÃO:
- RIGHT SHIFT abre o painel GALAXIAHACKS.
- RIGHT SHIFT novamente fecha o painel.
- O painel tem identidade visual roxa e mostra @diegoleite.58.
- O menu é apenas do lado do cliente e não exige alterações no servidor.

Configuração:
- Minecraft Java 26.1.2
- Fabric Loader 0.18.4
- Fabric API 0.155.3+26.1.2
- Java 25

Como compilar:
1. Num computador, instala JDK 25 e IntelliJ IDEA.
2. Extrai o ZIP e abre a pasta como projeto Gradle.
3. Aguarda a sincronização e executa Gradle > Tasks > build.
4. O JAR deverá aparecer em build/libs/.

Ainda é um protótipo inicial: não contém a galáxia 3D animada nem os módulos
de HUD. O painel atual é uma base visual para continuar o desenvolvimento.
Não inclui funções para obter vantagem injusta contra outros jogadores.

Documentação oficial:
https://docs.fabricmc.net/develop/key-mappings
https://docs.fabricmc.net/develop/rendering/gui/custom-screens
