package com.diegoleite.galaxiahacks;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

public final class GalaxiaHacksClient implements ClientModInitializer {
    public static final String MOD_ID = "galaxiahacks";

    private static KeyMapping openMenuKey;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath(MOD_ID, "main")
        );

        openMenuKey = KeyMappingHelper.registerKeyMapping(
                new KeyMapping(
                        "key.galaxiahacks.open_menu",
                        InputConstants.Type.KEYSYM,
                        InputConstants.KEY_RIGHT_SHIFT,
                        category
                )
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.consumeClick()) {
                if (client.screen == null) {
                    Minecraft.getInstance().setScreen(
                            new GalaxiaMenuScreen(Component.literal("GALAXIAHACKS"))
                    );
                } else if (client.screen instanceof GalaxiaMenuScreen) {
                    client.setScreen(null);
                }
            }
        });
    }
}
