package com.diegoleite.galaxiahacks;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class GalaxiaMenuScreen extends Screen {
    public GalaxiaMenuScreen(Component title) {
        super(title);
    }

    @Override
    protected void init() {
        int panelWidth = 300;
        int left = (this.width - panelWidth) / 2;
        int top = (this.height - 190) / 2;

        this.addRenderableWidget(Button.builder(
                Component.literal("Fechar painel"),
                button -> this.onClose()
        ).bounds(left + 85, top + 145, 130, 20).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);

        int panelWidth = 300;
        int panelHeight = 190;
        int left = (this.width - panelWidth) / 2;
        int top = (this.height - panelHeight) / 2;

        // Painel roxo escuro com contorno violeta.
        graphics.fill(left - 2, top - 2, left + panelWidth + 2, top + panelHeight + 2, 0xFFB45CFF);
        graphics.fill(left, top, left + panelWidth, top + panelHeight, 0xEE10051F);

        graphics.text(this.font, "GALAXIAHACKS", left + 16, top + 16, 0xFFE8C7FF, true);
        graphics.text(this.font, "@diegoleite.58", left + 16, top + 34, 0xFFB98BFF, true);
        graphics.fill(left + 16, top + 55, left + panelWidth - 16, top + 56, 0xFF7136B8);

        graphics.text(this.font, "PAINEL PRINCIPAL", left + 16, top + 70, 0xFFFFFFFF, true);
        graphics.text(this.font, "HUD  |  VISUAL  |  DEFINICOES", left + 16, top + 91, 0xFFD9C5F2, true);
        graphics.text(this.font, "Interface inicial — mais opções serão adicionadas.", left + 16, top + 113, 0xFFBFA9D8, true);
        graphics.text(this.font, "Roxo Galaxy • RIGHT SHIFT", left + 16, top + 130, 0xFFB45CFF, true);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
